#!/usr/bin/env python3
"""
	Allan Millar
	Machine profiling script
"""

def main():
    print

if __name__ == "__main__":
    main()