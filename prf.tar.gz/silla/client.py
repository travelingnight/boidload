#!/usr/bin/env python3
"""
	Allan Millar
    Remote client script, also serves as remote controller, receiving and 
	processing commands from parent machine.
"""

import sys
import socket
import time


def main():
    

if __name__ == "__main__":
    main()