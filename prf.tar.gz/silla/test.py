#!/usr/bin/env python3
"""
	Allan Millar
	testing script
"""
import sys, pexpect
from subprocess import Popen

def main():
    Popen(["python3", "./deliver_boidload.py"])

if __name__ == "__main__":
    main()